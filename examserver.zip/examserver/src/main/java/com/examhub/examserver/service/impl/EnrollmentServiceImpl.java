package com.examhub.examserver.service.impl;

import com.examhub.examserver.domain.dto.response.EnrollmentResponse;
import com.examhub.examserver.domain.dto.student.EnrollmentRequest;
import com.examhub.examserver.domain.entity.Course;
import com.examhub.examserver.domain.entity.Enrollment;
import com.examhub.examserver.domain.entity.User;
import com.examhub.examserver.domain.enums.EnrollmentStatus;
import com.examhub.examserver.exception.ResourceNotFoundException;
import com.examhub.examserver.exception.UnauthorizedException;
import com.examhub.examserver.exception.UserAlreadyExistsException;
import com.examhub.examserver.mapper.EnrollmentMapper;
import com.examhub.examserver.repository.CourseRepo;
import com.examhub.examserver.repository.EnrollmentRepo;
import com.examhub.examserver.repository.UserRepo;
import com.examhub.examserver.service.EnrollmentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional; // Added missing import
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class EnrollmentServiceImpl implements EnrollmentService {

    private final EnrollmentRepo enrollmentRepo;
    private final CourseRepo courseRepo;
    private final UserRepo userRepo;
    private final EnrollmentMapper enrollmentMapper;

    @Override
    @Transactional
    public EnrollmentResponse enrollStudent(Long courseId, Long userId, EnrollmentRequest request) {
        // Basic Existence Checks
        Course course = courseRepo.findById(courseId)
                .orElseThrow(() -> new ResourceNotFoundException("Course not found"));

        User user = userRepo.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        if (!course.isActive()) {
            throw new IllegalStateException("Cannot enroll in an inactive course");
        }

        // Business Logic Checks using your custom repo methods
        // Check for ANY existing enrollment (Clears 'findByUserIdAndCourseId' warning)
        Optional<Enrollment> existing = enrollmentRepo.findByUserIdAndCourseId(userId, courseId);
        if (existing.isPresent()) {
            throw new UserAlreadyExistsException("You are already linked to this course.");
        }

        // Check for specific PENDING state
        boolean isPending = enrollmentRepo.existsByUserIdAndCourseIdAndStatus(
                userId, courseId, EnrollmentStatus.PENDING
        );
        if (isPending) {
            throw new IllegalStateException("Your previous enrollment request is still being processed.");
        }

        // Create and Save
        Enrollment enrollment = new Enrollment();
        enrollment.setCourse(course);
        enrollment.setUser(user);
        enrollment.setStatus(EnrollmentStatus.PENDING); // Assuming default status
        enrollment.setPaymentMode(request.paymentMode());
        enrollment.setTransactionReference(request.transactionReference());

        return enrollmentMapper.toResponse(enrollmentRepo.save(enrollment));
    }

    @Override
    @Transactional(readOnly = true)
    public List<EnrollmentResponse> getEnrollmentsByUser(Long userId, Long currentUserId, String currentRole) {
        // Authorization check: students can only view their own enrollments
        if (!userId.equals(currentUserId) && !"ADMIN".equals(currentRole)) {
            throw new UnauthorizedException("You can only view your own enrollments.");
        }
        return enrollmentRepo.findByUserIdWithDetails(userId).stream()
                .map(enrollmentMapper::toResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<EnrollmentResponse> getEnrollmentsByCourse(Long courseId) {
        return enrollmentRepo.findByCourseIdWithDetails(courseId).stream()
                .map(enrollmentMapper::toResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public void cancelEnrollment(Long enrollmentId) {
        Enrollment enrollment = enrollmentRepo.findById(enrollmentId)
                .orElseThrow(() -> new ResourceNotFoundException("Enrollment record not found"));
        // Soft delete: archive instead of hard delete
        enrollment.setArchived(true);
        enrollment.setStatus(EnrollmentStatus.CANCELLED);
        enrollmentRepo.save(enrollment);
    }

    @Override
    @Transactional
    public EnrollmentResponse updateStatus(Long enrollmentId, EnrollmentStatus status, String adminRemarks) {
        Enrollment enrollment = enrollmentRepo.findById(enrollmentId)
                .orElseThrow(() -> new ResourceNotFoundException("Enrollment not found with id: " + enrollmentId));

        enrollment.setStatus(status);
        enrollment.setAdminRemarks(adminRemarks);

        Enrollment updatedEnrollment = enrollmentRepo.save(enrollment);
        return enrollmentMapper.toResponse(updatedEnrollment);
    }

    @Override
    @Transactional
    public void unlockCourse(Long enrollmentId) {
        Enrollment enrollment = enrollmentRepo.findById(enrollmentId)
                .orElseThrow(() -> new ResourceNotFoundException("Enrollment not found"));

        if (enrollment.getStatus() != EnrollmentStatus.EXAM_LOCKED) {
            throw new IllegalStateException("This course is not currently locked.");
        }

        // Reset from 3 fails back to 2, granting exactly 1 more attempt across the course
        enrollment.setFailedAttempts(2);
        enrollment.setStatus(EnrollmentStatus.PAID);
        enrollmentRepo.save(enrollment);
    }

    @Transactional(readOnly = true)
    public List<EnrollmentResponse> getEnrollmentsByStatus(EnrollmentStatus status) {
        return enrollmentRepo.findByStatusWithDetails(status).stream()
                .map(enrollmentMapper::toResponse)
                .collect(Collectors.toList());
    }
}